﻿The usage of websites has become one of the most popular trends in the modern world, as a plethora of people applies various websites for education, work, entertainment, household chores

along with other implementations. This long list of websites also includes networking for carsharing, which has a tendency of being the reason for decreasing the number of private cars.

So, the carsharing website was created to make a contribution to its flourishment in Uzbekistan. The web page consists of 7 pages: Home page, Vehicles page, About Cars page, About Us page,

News page, FAQs page and Contact Us page. To commence, vehicles and About Cars pages include information about the models, technical characteristics, and leasing prices of cars. When it

comes to About Us, News, and FAQs pages they mainly focused on the updated, new innovations and the important facts that should be known about vehicles. The contact page is needed to

connect with the organization. JavaScript, CSS, and HTML were used to create a website. A number of JavaScript files were implemented, for example, to make accordions for the FAQs section,

filter for Vehicles section, slider for About Us section also for hamburger and navigation bar. However, inspiration for the development of this website comes from the web pages of

vehicle-producing companies.

Link to website:

https://islom27.github.io/

Link to GitHub:

https://github.com/Islom27/islom27

Reference list:

“Frequently Asked Questions.” Kia Motors Australia, www.kia.com/au/util/faq.html#.

Accessed 9 Dec. 2021.

“Модельный ряд Kia – комплектации и цены на новые автомобили Киа 2021.” Www.kia.ru, www.kia.ru/models/. Accessed 9 Dec. 2021.

“SUVs, Sedans, Sports Car, Hybrids, EVs, Minivans & Luxury Cars | Kia.” Kia.com, www.kia.com/us/en.
